window.onload=function() {
	feetObj = document.getElementById('feet');
    inchesObj = document.getElementById('inches');
	resultsObj = document.getElementById('results');
	document.getElementById('clear').onclick = clearInputs;
    document.getElementById('convert').onclick = HeightConverted
}


function clearInputs() {
    feetObj.value = '';
    inchesObj.value = '';
	resultsObj.innerHTML = '';
}

function HeightConverted () {
	var feet = new Number (feetObj);
	var inches = new Number (inchesObj);
	var feetToCm = feet * 30.48 ;
	var inchesToCm = inches * 2.54;
	var convertedHeight;
	return feetToCm + inchesToCm;
resultsObj.innerHTML = convertedHeight;
}
	
	
